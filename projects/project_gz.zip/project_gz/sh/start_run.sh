#!/usr/bin/env sh

(cd ../run; ./programme_v2.py)