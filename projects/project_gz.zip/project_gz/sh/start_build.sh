#!/usr/bin/env sh

(cd ../build; ./pipeline_v2.py && ./Regressor_v2.py)